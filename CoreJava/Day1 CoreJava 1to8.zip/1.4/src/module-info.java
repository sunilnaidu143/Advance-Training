module Rectangular1 {
}