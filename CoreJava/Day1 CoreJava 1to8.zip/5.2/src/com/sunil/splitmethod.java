package com.sunil;

public class splitmethod {
	public static void main(String[] args) {
		
		
		String txt= (" 23  +  45  -  (  343  /  12  ) ");
		String[] arrOftxt = txt.split("");
		
		for(String w1:arrOftxt){  
			System.out.println(w1); 
			//System.out.println(" ");
		}
	}
}
