module Rectangular {
}