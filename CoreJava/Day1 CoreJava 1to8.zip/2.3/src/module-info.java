module IntegerArray {
}